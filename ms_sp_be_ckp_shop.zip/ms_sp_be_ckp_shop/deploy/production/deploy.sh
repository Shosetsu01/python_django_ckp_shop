# Обновляем публичный ключ gitlab.muctr.ru
ssh-keyscan gitlab.muctr.ru >> ~/.ssh/known_hosts

# Требуемые параметры для корректной работы:
#   PROJECT_NAME - базовое название проекта
#   PROD_mcpc02_SECRET - секрет цефа
#   PROD_SECRETS_ENVS - секреты проекта
#   PROJECT_REQUIREMENTS - файл реквариментов
# Дополнительные параметры
#   PROJECT_SECRETS_NAME - если отличаются от secrets
#   BRANCH_NAME - если отличается от master
#   PROJECT_SECOND_NAME - внутренее имя если отчличается
#   PROJECT_DEPLOY_DIR_NAME - папка диплоя если отличается от production

[[ ! -z $PROJECT_NAME ]] || exit 1

PROJECT_DIR=/srv/$PROJECT_NAME
PROJECT_VENV_DIR=/srv/.venvs/$PROJECT_NAME
PROJECT_LOG_BASE_DIR=/var/log/$PROJECT_NAME
CELERY_QUEUES=()
PYTHON=3.9

[[ ! -z $PROJECT_SECRETS_NAME ]] || PROJECT_SECRETS_NAME='secrets'
[[ ! -z $BRANCH_NAME ]] || BRANCH_NAME='master'
[[ ! -z $PROJECT_SECOND_NAME ]] || PROJECT_SECOND_NAME=$PROJECT_NAME
[[ ! -z $PROJECT_DEPLOY_DIR_NAME ]] || PROJECT_DEPLOY_DIR_NAME="production"
[[ ! -z $PROJECT_REQUIREMENTS ]] || PROJECT_REQUIREMENTS="requirements/production"

DJANGO_DIR=$PROJECT_DIR/$PROJECT_SECOND_NAME

echo -e "Deploy ${PROJECT_NAME} (git@gitlab.muctr.ru:itmuctr/small_projects/${$PROJECT_NAME.git}) from branch ${BRANCH_NAME}"

# Получаем данные репозитория
echo -e "Clone repository"
cd /srv || exit 1
if ! git clone --branch $BRANCH_NAME git@gitlab.muctr.ru:itmuctr/small_projects/$PROJECT_NAME.git; then
   cd $PROJECT_NAME || exit 1
   git pull origin $BRANCH_NAME
fi

echo -e "Set secrets"
# Обновляем секреты
mkdir -p $PROJECT_VENV_DIR
echo "$PROD_mcpc02_SECRET" > $PROJECT_VENV_DIR/$PROJECT_NAME.mcpc02.secret
echo "$PROD_SECRETS" > $PROJECT_VENV_DIR/$PROJECT_SECRETS_NAME

echo -e "Install apts"
# Устанавливаем необходимые пакеты
apt update --fix-missing
apt -y install python$PYTHON-dev python$PYTHON-venv python3-setuptools python3-pip python3-wheel default-libmysqlclient-dev build-essential ceph-common bindfs nginx

echo -e "Create user"
# Создаем пользователя
useradd -b $PROJECT_VENV_DIR/ -d $PROJECT_VENV_DIR/ -p "$(openssl rand -hex 8)" $PROJECT_NAME

echo -e "Create dirs"
# Создаем нужные директории
mkdir /var/log/nginx/zabbix-monitor
mkdir -p $PROJECT_LOG_BASE_DIR/django
#mkdir -p $PROJECT_LOG_BASE_DIR/periodic
mkdir -p $PROJECT_LOG_BASE_DIR/nginx/access
mkdir -p $PROJECT_LOG_BASE_DIR/nginx/error
mkdir -p $PROJECT_LOG_BASE_DIR/systemd/gunicorn

for QUEUE in "${CELERY_QUEUES[@]}"; do
  mkdir -p $PROJECT_LOG_BASE_DIR/systemd/celery/"$QUEUE"
  mkdir -p $PROJECT_LOG_BASE_DIR/celery/"$QUEUE"
done

echo -e "Create env"
# Создаем виртуальное окружение проекта
python$PYTHON -m venv $PROJECT_VENV_DIR

grep -qxF "source $PROJECT_VENV_DIR/$PROJECT_SECRETS_NAME" $PROJECT_VENV_DIR/bin/activate || echo -e "source $PROJECT_VENV_DIR/$PROJECT_SECRETS_NAME\n" >> $PROJECT_VENV_DIR/bin/activate

echo -e "Set up env"
# Активируем виртуальное окружение проекта
source $PROJECT_VENV_DIR/bin/activate
#source $PROJECT_VENV_DIR/$PROJECT_SECRETS_NAME
#export SECRETS_PATH="/srv/.venvs/ms_be_pay/secrets.json"

echo -e "Install packages"
# Устанавливаем пакеты
pip$PYTHON install wheel
if ! pip$PYTHON install -r $PROJECT_DIR/$PROJECT_REQUIREMENTS --upgrade; then
     exit 1
fi

echo -e "Setup premissions"
# Раздаем права на директории
chown -R $PROJECT_NAME:$PROJECT_NAME $PROJECT_DIR $PROJECT_VENV_DIR $PROJECT_LOG_BASE_DIR

echo -e "Migrate models"
# Выполняем миграции
if ! $DJANGO_DIR/manage.py migrate; then
     exit 1
fi

$DJANGO_DIR/manage.py collectstatic --noinput

PROJECT_DEPLOY_PATH=$PROJECT_DIR/deploy/$PROJECT_DEPLOY_DIR_NAME

echo -e "Update systemd"
# Обновляем файлы демонов и запускаем их
find $PROJECT_DEPLOY_PATH/systemd/ -type f | while read sfile; do
  name=$(basename $sfile)
  rm -f /etc/systemd/system/$name
  ln -sf $sfile /etc/systemd/system/$name
    # shellcheck disable=SC2076
  if [[ $name =~ ".timer" ]]; then
    systemctl enable $name
  fi
done
#find /etc/systemd/system/. -xtype l -delete
#ln -sf $PROJECT_DEPLOY_PATH/systemd/* /etc/systemd/system/

systemctl enable $PROJECT_NAME.target
systemctl daemon-reload
systemctl restart $PROJECT_NAME.target

echo -e "Update nginx"
# Обновляем файлы NGINX и делаем перезагрузку
rm /etc/nginx/sites-enabled/*
find /etc/nginx/sites-enabled/. -xtype l -delete
ln -sf $PROJECT_DEPLOY_PATH/nginx/* /etc/nginx/sites-enabled/
if ! nginx -t; then
     exit 1
fi
if ! service nginx restart; then
     exit 1
fi

exit 0
