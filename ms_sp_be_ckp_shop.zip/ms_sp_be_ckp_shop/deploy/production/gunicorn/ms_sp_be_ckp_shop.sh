#!/bin/bash

PROJECT_NAME="ms_sp_be_ckp_shop"
ROOT_DIR=/srv
ENV_DIR=$ROOT_DIR/.venvs/$PROJECT_NAME
DJANGO_DIR=$ROOT_DIR/$PROJECT_NAME/ckp_shop
SOCK_FILE=$ENV_DIR/run/gunicorn.sock
USER=$PROJECT_NAME
GROUP=$PROJECT_NAME
NUM_WORKERS=2
LOGFILE_DIR=/var/log/$PROJECT_NAME/gunicorn
LOGFILE=$LOGFILE_DIR/$PROJECT_NAME.log

cd $DJANGO_DIR

[ -d $LOGFILE_DIR ] || mkdir -p $LOGFILE_DIR

source $ENV_DIR/bin/activate

export PYTHONPATH=$DJANGO_DIR:$PYTHONPATH

#export SECRETS_PATH="/srv/.venvs/ms_be_pay/secrets.json"

mkdir -p "$(dirname $SOCK_FILE)"

exec $ENV_DIR/bin/gunicorn config.wsgi:application \
  --name $PROJECT_NAME \
  --workers $NUM_WORKERS \
  --user=$USER \
  --group=$GROUP \
  --bind=unix:$SOCK_FILE \
  --log-level=debug \
  --log-file=$LOGFILE