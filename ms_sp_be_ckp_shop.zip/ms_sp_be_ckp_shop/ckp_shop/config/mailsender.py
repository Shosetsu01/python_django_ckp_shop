import os
import smtplib
import time
from django.core.exceptions import ImproperlyConfigured
from rest_framework.pagination import PageNumberPagination
from rest_framework.utils.urls import remove_query_param, replace_query_param
from config.utils import Singleton, EnviromentVariable
# from configparameters.models import ConfigParameterSection


class MailServerConection(metaclass=Singleton):
    _mailserver = None
    _sended = 0
    _connected = False

    def __init__(self, **kwargs):
        super().__init__()
        self.reinint(**kwargs)
        # self.set_config('name', kwargs)
        # self.set_config('password', kwargs)
        # self.set_config('server', kwargs)
        # self.set_config('port', kwargs)
        # self.set_config('max_recipients', kwargs)
        # self._sended = 0

    def reinint(self, **kwargs):
        self.quit()
        self.set_config('name', kwargs)
        self.set_config('password', kwargs)
        self.set_config('server', kwargs)
        self.set_config('port', kwargs)
        self.set_config('max_recipients', kwargs)
        self._sended = 0
        return self

    def __del__(self):
        self._mailserver.quit()
        self._mailserver = None

    def get_from_default(self, attr):
        ENV = EnviromentVariable()
        if attr == 'name':
            return ENV.SENDER_EMAIL
        elif attr == 'password':
            return ENV.SENDER_PASSWORD
        elif attr == 'server':
            return ENV.SENDER_SERVER
        elif attr == 'port':
            return ENV.SENDER_PORT
        elif attr == 'max_recipients':
            return ENV.SENDER_MAX_RECIPIENTS
        return ''

    def set_config(self, attr, kwargs):
        if attr in kwargs:
            self.__setattr__('_' + attr, kwargs[attr])
        else:
            self.__setattr__('_' + attr, self.get_from_default(attr))

    def is_connected(self):
        if self._mailserver is None:
            return False
        try:
            status = self._mailserver.noop()
        except smtplib.SMTPServerDisconnected:
            status = -1
        return True if status == 250 else False

    def connect(self):
        if not self.is_connected():
            while True:
                try:
                    self._mailserver = smtplib.SMTP_SSL(self._server, self._port)
                    self._mailserver.connect(self._server, self._port)
                    self._mailserver.login(self._name, self._password)
                    break
                except smtplib.SMTPConnectError:
                    time.sleep(3)
                except smtplib.SMTPServerDisconnected:
                    time.sleep(2)
            # self._sended = 0
        self._connected = True

    def reconnect(self, wait=0):
        self.quit()
        if wait > 0:
            time.sleep(wait)
        self.connect()

    def quit(self):
        if self.is_connected():
            self._mailserver.quit()
        self._sended = 0
        self._mailserver = None
        self._connected = False

    def send_message(self, msg):
        if not self._connected:
            self.connect()
        msg['FROM'] = self._name
        if self._sended >= int(self._max_recipients):
            self.reconnect(15)
        while True:
            try:
                self._mailserver.send_message(msg)
                self._sended += 1
                break
            except smtplib.SMTPConnectError:
                self.reconnect(2)
            except smtplib.SMTPServerDisconnected:
                self.reconnect(2)
            except smtplib.SMTPSenderRefused:
                self.reconnect(2)
            except smtplib.SMTPRecipientsRefused:
                self.reconnect(5)