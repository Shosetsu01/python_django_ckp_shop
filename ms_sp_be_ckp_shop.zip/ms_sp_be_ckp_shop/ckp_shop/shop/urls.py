from rest_framework import routers
from .views import ProductViewSet, OrderViewSet
from django.urls import include, path

# Создаем router и регистрируем наш ViewSet
router = routers.DefaultRouter()
router.register(r'product', ProductViewSet)

# URLs настраиваются автоматически роутером
urlpatterns = [
    path('', include(router.urls)),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    path('order/', OrderViewSet.as_view())
]
