from rest_framework import serializers
from .models import Product, OrderUr, OrderProduct, OrderFiz, OrderFizProduct


class ProductSerializer(serializers.ModelSerializer):
    """Сериалайзер Услуг"""
    class Meta:
        model = Product
        fields = ('category', 'id', 'name', 'equipment', 'equipmentNote', 'note', 'price', 'quantity')


class OrderProductSerializer(serializers.ModelSerializer):
    """Сериалайзер Заказанных услуг Юрлиц"""
    class Meta:
        model = OrderProduct
        fields = ('id', 'order', 'product', 'price', 'quantity')
        read_only_fields = ['id', 'order']


class OrderFizProductSerializer(serializers.ModelSerializer):
    """Сериалайзер Заказанных услуг Физлиц"""
    class Meta:
        model = OrderFizProduct
        fields = ('id', 'order', 'product', 'price', 'quantity')
        read_only_fields = ['id', 'order']


class OrderUrSerializer(serializers.ModelSerializer):
    """Сериалайзер Заказов Юрлиц"""
    order_products = OrderProductSerializer(many=True, required=True, source='items')

    class Meta:
        model = OrderUr
        fields = (
            'id', 'document', 'email', 'fullName', 'shortName', 'name', 'position', 'requisites', 'order_products')
        read_only_fields = ['id']

    def create(self, validated_data):
        """Функция для создания объектов услуг заказа в БД"""
        order_products = validated_data.pop('items')
        # print(validated_data)
        instance: OrderUr = super().create(validated_data)
        for obj in order_products:
            obj['order'] = instance
            OrderProduct.objects.create(**obj)
        return instance


class OrderFizSerializer(serializers.ModelSerializer):
    order_products = OrderFizProductSerializer(many=True, required=True, source='fiz_items')

    class Meta:
        model = OrderFiz
        fields = ('id', 'fio', 'serial', 'number',
                  'place', 'date', 'address', 'email', 'requisites', 'order_products', 'birthday', 'phone')
        read_only_fields = ['id']

    def create(self, validated_data):
        """Функция для создания объектов услуг заказа в БД"""
        order_products = validated_data.pop('fiz_items')
        # print(validated_data)
        instance: OrderFiz = super().create(validated_data)
        for obj in order_products:
            obj['order'] = instance
            OrderFizProduct.objects.create(**obj)
        return instance
