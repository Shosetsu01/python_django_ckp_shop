from django.db import models


class Category(models.Model):
    """Модель категорий услуг

    Атрибуты:
        name (str): Поле названия категории

    """
    name = models.CharField(max_length=200, db_index=True)

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'

    def __str__(self):
        return self.name


class Product(models.Model):
    """Модель услуг

    Атрибуты:
        category : Категория из Модели:Category
        id (int): Параметр номера услуги в базе
        name (str): Имя услуги
        equipment (str): Описание оборудования для услуги
        equipmentNote (str): Примечение для оборудования
        note (str): Примечание для услуги
        price (int): Цена услуги
        quantity (str): Системный параметр, для подсчета кол-ва услуг при добавлении его в заказ (в БД должен равняться 0)
        available (bool): Доступность услуги к заказу
        created (date): Системный параметр для отображения времени создания услуги
        updated (date): Системный параметр для отображения времени редактирования услуги

    """
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    id = models.AutoField(primary_key=True)
    name = models.TextField(blank=True, db_index=True, max_length=1000)
    equipment = models.TextField(blank=True)
    equipmentNote = models.TextField(blank=True)
    note = models.TextField(blank=True)
    price = models.DecimalField(max_digits=10, decimal_places=0)
    quantity = models.PositiveIntegerField(default=0)
    available = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Услуга'
        verbose_name_plural = 'Услуги'

    def __str__(self):
        return self.name


class OrderUr(models.Model):
    """Заказы Юрлиц

    Атрибуты:
        document (str): Название документа на основании которого заказчик выступает от Юрлица
        email (email): Электронная почта заказчика
        fullName (str): Полное наименование организации
        shortName (str): Краткое наименование организации
        name (str): Имя физлица выступающего представителем юрлица
        position (str): Должность физлица в организации
        requisites (str): Реквизиты заказчика

    """
    document = models.CharField(max_length=200, db_index=True)
    email = models.EmailField(blank=True)
    fullName = models.CharField(max_length=200, db_index=True)
    shortName = models.CharField(max_length=200, db_index=True)
    name = models.CharField(max_length=200, db_index=True)
    position = models.CharField(max_length=200, db_index=True)
    requisites = models.TextField(blank=True, db_index=True)

    class Meta:
        verbose_name = 'Заказ Юридическое лицо'
        verbose_name_plural = 'Заказы Юридических лиц'

    def __str__(self):
        return self.shortName


class OrderFiz(models.Model):
    """Заказа Физлиц

    Атрибуты:
        fio (str): ФИО заказчика
        serial (int): Серия паспорта заказчика
        number (int): Номер паспорта заказчика
        place (str): Местро выдачи паспорта заказчика
        date (date): Дата выдачи паспорта заказчика
        address (str): Адрес проживания заказчика
        email (email): Электронная почта заказчика
        requisites (str): Реквизиты заказчика

    """
    fio = models.CharField(max_length=200, db_index=True)
    serial = models.CharField(max_length=4, db_index=True)
    number = models.CharField(max_length=6, db_index=True)
    place = models.CharField(max_length=200, db_index=True)
    date = models.DateField(blank=True)
    address = models.CharField(max_length=200, db_index=True)
    email = models.EmailField(blank=True)
    requisites = models.TextField(blank=True, db_index=True)
    phone = models.CharField(max_length=11, db_index=True)
    birthday = models.DateField(blank=True, null=True)

    class Meta:
        verbose_name = 'Заказ Физическое лицо'
        verbose_name_plural = 'Заказы Физических лиц'

    def __str__(self):
        return self.fio


class OrderProduct(models.Model):
    """Заказанные услуги Юрлиц

    Атрибуты:
        order (str): Связь с моделью заказчика
        product (str): Наименование заказанной услуги
        price (int): Цена заказанной услуги
        quantity (int): Кол-во заказанной услуги

    """
    order = models.ForeignKey(OrderUr, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, related_name='order_items', on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=0)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return '{}'.format(self.id)


class OrderFizProduct(models.Model):
    """Заказанные услуги Физлиц

        Атрибуты:
            order (str): Связь с моделью заказчика
            product (str): Наименование заказанной услуги
            price (int): Цена заказанной услуги
            quantity (int): Кол-во заказанной услуги

        """
    order = models.ForeignKey(OrderFiz, related_name='fiz_items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, related_name='fiz_order_items', on_delete=models.CASCADE)
    price = models.DecimalField(max_digits=10, decimal_places=0)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return '{}'.format(self.id)

