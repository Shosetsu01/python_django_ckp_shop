from django.contrib import admin
from .models import Category, Product, OrderProduct, OrderUr, OrderFiz, OrderFizProduct


class CategoryAdmin(admin.ModelAdmin):
    """Класс категорий услуг"""
    list_display = ['name']


admin.site.register(Category, CategoryAdmin)


class ProductAdmin(admin.ModelAdmin):
    """Класс услуг"""
    list_display = ['name', 'equipment', 'equipmentNote', 'note', 'price', 'quantity', 'available']
    list_filter = ['available', 'created', 'updated']
    list_editable = ['price', 'available']


admin.site.register(Product, ProductAdmin)


class OrderItemInline(admin.TabularInline):
    """Класс заказанных товаров юрлиц"""
    model = OrderProduct
    raw_id_fields = ['product']


class OrderUrAdmin(admin.ModelAdmin):
    """Класс заказов юрлиц"""
    list_display = ['id', 'document', 'email', 'fullName',
                    'shortName', 'name', 'position', 'requisites']
    inlines = [OrderItemInline]


admin.site.register(OrderUr, OrderUrAdmin)


class OrderFizItemInline(admin.TabularInline):
    """Класс заказанных товаров физлиц"""
    model = OrderFizProduct
    raw_id_fields = ['product']


class OrderFizAdmin(admin.ModelAdmin):
    """Класс заказов физлиц"""
    list_display = ['id', 'fio', 'serial', 'number',
                    'place', 'date', 'address', 'email', 'requisites', 'birthday', 'phone']
    inlines = [OrderFizItemInline]


admin.site.register(OrderFiz, OrderFizAdmin)
