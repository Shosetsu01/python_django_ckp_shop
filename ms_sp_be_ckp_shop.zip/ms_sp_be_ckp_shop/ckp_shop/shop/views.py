from rest_framework import viewsets, generics
from rest_framework.permissions import AllowAny
from .models import Product
from .serializers import ProductSerializer, OrderUrSerializer, OrderFizSerializer
from .services import send_order_ur, send_order_fiz


class ProductViewSet(viewsets.ReadOnlyModelViewSet):
    """Отправка перечня услуг из БД на фронт"""
    queryset = Product.objects.all()
    serializer_class = ProductSerializer


class OrderViewSet(generics.CreateAPIView):
    """Прием заказов"""
    serializer_class = OrderUrSerializer, OrderFizSerializer
    permission_classes = [AllowAny]

    def perform_create(self, serializer):
        """Проверка от кого пришел заказ (физлицо или юрлицо)
            и вызов функции формирования документа и отправки на почту"""
        # print("validate data: ", serializer.validated_data)
        super().perform_create(serializer)
        # print("instance: ", serializer.instance)
        if 'agent' in self.request.data:
            if self.request.data['agent']:
                send_order_fiz(serializer.instance)
            else:
                send_order_ur(serializer.instance)

    def get_serializer_class(self):
        """Проверка от кого пришел заказ (физлицо или юрлицо)
            и отправка данныз для записи в БД"""
        if 'agent' in self.request.data:
            if self.request.data['agent']:
                return OrderFizSerializer
            else:
                return OrderUrSerializer
        raise NotImplementedError


