import io
from docxtpl import DocxTemplate
from num2t4ru import num2text
from .models import OrderUr, OrderFiz
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from config.mailsender import MailServerConection
from django.template.loader import render_to_string
from django.conf import settings
from datetime import datetime


def attach_files(msg, file, file_name):
    part = MIMEApplication(
        file.read(),
        Name=file_name
    )
    part['Content-Disposition'] = 'attachment; filename="%s"' % file_name
    msg.attach(part)
    return msg


def send_to_reply_mail(order, file, file_name, name):
    msg = MIMEMultipart()
    msg['To'] = order.email
    msg['From'] = settings.FEEDBACK_TO_EMAIL
    msg['Subject'] = f'''
        Заказ от {name}, дата заказа {datetime.now()}
    '''
    message = render_to_string("shop/to_reply_msg.html", context={'order': order})
    msg.attach(MIMEText(message, 'html'))
    msg = attach_files(msg, file, file_name)
    MailServerConection().send_message(msg)


def send_to_manager_mail(order, file, file_name, name):
    msg = MIMEMultipart()
    msg['To'] = settings.FEEDBACK_TO_EMAIL
    msg['From'] = order.email
    msg['Subject'] = f'''
        Заказ от {name}, дата заказа {datetime.now()}
    '''
    message = render_to_string("shop/to_support_msg.html", context={'order': order})
    msg.attach(MIMEText(message, 'html'))
    msg = attach_files(msg, file, file_name)
    MailServerConection().send_message(msg)


def send_order_ur(order: OrderUr):
    """"Функция формирования файла DOCX из шаблона (юрлицо)

    Args:
        doc : переменная для получения шаблона документа
        products : queryset для получения данных о заказанных услугах
        signer (str): форматирует fio в формат 'Фамилия И.О.'
        total (int): переменная для подсчета общей суммы заказа
        nds (int): переменная для вычисления суммы НДС
        no_nds_total (int): переменная для вычисления суммы заказа без учета НДС

    """
    doc = DocxTemplate('shop/docs/ur_template.docx')
    products = order.items.all()
    signer = u'{} {}.{}.'.format(    # Шаблон, в который подставим строки
            order.name[:order.name.find(' ')],     # Всё до первого пробела - Фамилия
            order.name[order.name.find(' ') + 1],  # Первая буква после первого пробела - И.
            order.name[order.name.rfind(' ') + 1]  # Первая буква после последнего пробела - О.
            )

    no_nds_total = 0
    for product in products:
        no_nds_total += product.price * product.quantity
    total = no_nds_total / 100 * 120
    nds = total - no_nds_total
    now = datetime.now()
    months = ['none', 'января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'сентября', 'ноября', 'декабря']
    context = {'day': now.day,
               'month': months[now.month],
               'year': now.year,
               'document': order.document,
               'email': order.email,
               'fullName': order.fullName,
               'shortName': order.shortName,
               'name': order.name,
               'position': order.position,
               'requisites': order.requisites,
               'products': products,
               'total': total,
               'total_text': num2text(total),
               'nds_text': num2text(nds),
               'nds': nds,
               'no_nds_total': no_nds_total,
               'signer': signer,
               }
    doc.render(context)
    file = io.BytesIO()
    doc.save(file)
    file.seek(0)
    file_name = f"{order.id}_{order.email[:80]}_{now.strftime('%d.%m.%Y_%H_%M')}.docx"
    send_to_manager_mail(order, file, file_name, order.shortName)
    file.seek(0)
    send_to_reply_mail(order, file, file_name, order.shortName)


def send_order_fiz(order: OrderFiz):
    """Функция формирования файла DOCX из шаблона (физлицо)

    Args:
        doc : переменная для получения шаблона документа
        products : queryset для получения данных о заказанных услугах
        signer (str): форматирует fio в формат 'Фамилия И.О.'
        total (int): переменная для подсчета общей суммы заказа
        nds (int): переменная для вычисления суммы НДС
        no_nds_total (int): переменная для вычисления суммы заказа без учета НДС

    """
    doc = DocxTemplate('shop/docs/fiz_template.docx')
    products = order.fiz_items.all()
    signer = u'{} {}.{}.'.format(  # Шаблон, в который подставим строки
        order.fio[:order.fio.find(' ')],  # Всё до первого пробела - Фамилия
        order.fio[order.fio.find(' ') + 1],  # Первая буква после первого пробела - И.
        order.fio[order.fio.rfind(' ') + 1]  # Первая буква после последнего пробела - О.
    )

    no_nds_total = 0
    for product in products:
        no_nds_total += product.price * product.quantity
    total = no_nds_total / 100 * 120
    nds = total - no_nds_total
    now = datetime.now()
    months = ['none', 'января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'сентября',
              'ноября', 'декабря']
    context = {'day': now.day,
               'month': months[now.month],
               'year': now.year,
               'fio': order.fio,
               'email': order.email,
               'serial': order.serial,
               'number': order.number,
               'place': order.place,
               'date': order.date,
               'address': order.address,
               'requisites': order.requisites,
               'products': products,
               'total': total,
               'total_text': num2text(total),
               'nds_text': num2text(nds),
               'nds': nds,
               'no_nds_total': no_nds_total,
               'signer': signer,
               'birthday': order.birthday,
               'phone': order.phone,
               }
    doc.render(context)
    file = io.BytesIO()
    doc.save(file)
    file.seek(0)
    file_name = f"{order.id}_{order.email[:80]}_{now.strftime('%d.%m.%Y_%H_%M')}.docx"
    send_to_manager_mail(order, file, file_name, order.fio)
    file.seek(0)
    send_to_reply_mail(order, file, file_name, order.fio)
